import pygame
import math

# Khởi tạo
pygame.init()
width, height = 1000, 500
screen = pygame.display.set_mode((width, height), pygame.DOUBLEBUF)
clock = pygame.time.Clock()

def get_bezier_point(p0, p1, p2, p3, t):
    """Cubic Bezier: Mượt gấp đôi bậc 2"""
    x = (1-t)**3*p0[0] + 3*(1-t)**2*t*p1[0] + 3*(1-t)*t**2*p2[0] + t**3*p3[0]
    y = (1-t)**3*p0[1] + 3*(1-t)**2*t*p1[1] + 3*(1-t)*t**2*p2[1] + t**3*p3[1]
    return (x, y)

def get_apple_color(t_global):
    """Màu sắc chuyển từ Xanh -> Vàng -> Cam -> Đỏ -> Tím"""
    colors = [
        (106, 190, 185), # Teal
        (229, 215, 81),  # Yellow
        (241, 145, 75),  # Orange
        (223, 93, 83),   # Red
        (146, 107, 180)  # Purple
    ]
    idx = int(t_global * (len(colors) - 1))
    frac = (t_global * (len(colors) - 1)) - idx
    if idx >= len(colors) - 1: return colors[-1]
    
    # Mix màu mượt mà
    c1, c2 = colors[idx], colors[idx+1]
    return (
        int(c1[0] + (c2[0]-c1[0])*frac),
        int(c1[1] + (c2[1]-c1[1])*frac),
        int(c1[2] + (c2[2]-c1[2])*frac)
    )

# Tọa độ chuẩn hơn cho chữ 'hello' nối liền
# Mỗi nét: (Start, Control1, Control2, End)
strokes = [
    ((100, 350), (80, 50), (180, 50), (180, 350)),   # h (thân)
    ((180, 280), (220, 200), (280, 200), (280, 350)), # h (móc)
    ((320, 300), (450, 150), (350, 100), (320, 300)), # e (vòng)
    ((320, 300), (320, 400), (450, 350), (450, 320)), # e (đuôi)
    ((480, 350), (520, 20), (580, 20), (550, 350)),   # l 1
    ((600, 350), (640, 20), (700, 20), (670, 350)),   # l 2
    ((850, 280), (850, 150), (720, 150), (720, 280)), # o (trên)
    ((720, 280), (720, 400), (850, 400), (880, 280)), # o (dưới)
    ((880, 280), (920, 280), (950, 220), (980, 200))  # nét hất
]

all_points = []
current_stroke = 0
t = 0.0

running = True
while running:
    screen.fill((255, 255, 255))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if current_stroke < len(strokes):
        p0, p1, p2, p3 = strokes[current_stroke]
        pos = get_bezier_point(p0, p1, p2, p3, t)
        
        # Tính toán độ dày nét (Tapering)
        # Nét vẽ sẽ mảnh ở t=0 và t=1, dày ở giữa (t=0.5)
        thickness = int(math.sin(t * math.pi) * 8 + 6)
        
        # Lấy màu theo tiến trình tổng thể
        progress = (current_stroke + t) / len(strokes)
        color = get_apple_color(progress)
        
        all_points.append((pos, color, thickness))
        
        t += 0.08
        if t > 1.0:
            t = 0.0
            current_stroke += 1

    # Vẽ với hiệu ứng giả lập Brush (Cọ)
    for i in range(1, len(all_points)):
        p, color, size = all_points[i]
        # Vẽ nhiều vòng tròn đè lên nhau tạo độ mịn
        pygame.draw.circle(screen, color, (int(p[0]), int(p[1])), size)
        # Thêm một chút bóng mờ nhẹ xung quanh (tùy chọn)
        # pygame.draw.circle(screen, (*color, 50), (int(p[0]), int(p[1])), size + 2)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()