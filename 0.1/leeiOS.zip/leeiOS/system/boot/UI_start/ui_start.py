import pygame
pygame.init()   #khởi tạo Pygame để sử dụng các chức năng của nó
display = pygame.display.set_mode((1300, 800))  #tạo cửa sổ hiển thị với kích thước 1300x800 pixel
pygame.display.set_caption("booting...")  #đặt tiêu đề cho cửa sổ hiển thị là "booting..."
logo_boot = pygame.image.load(r"C:\Users\ble39\AppData\Roaming\leeiOS\system\lib\picture\hello_boot.png") #tải hình ảnh logo khởi động từ đường dẫn cụ thể và lưu vào biến logo_boot
hello_boot_original = pygame.image.load(r"C:\Users\ble39\AppData\Roaming\leeiOS\system\lib\picture\hello_boot.png").convert_alpha() #tải hình ảnh hello boot từ đường dẫn cụ thể và lưu vào biến hello_boot

hello_boot_alpha = 0
hello_boot.set_alpha(hello_boot_alpha)  #đặt độ trong suốt của hình ảnh hello_boot bằng giá trị của biến hello_boot_alpha (ban đầu là 0, tức là hoàn toàn trong suốt)

#bien 
dem_loading = 450
load_start = True
last_time = pygame.time.get_ticks()  #lấy thời gian hiện tại tính bằng mili giây kể từ khi Pygame được khởi tạo và lưu vào biến last_time
ban_kinh = 5
run = True #biến điều khiển vòng lặp chính của chương trình, ban đầu được đặt thành True để bắt đầu vòng lặp
dem_icon_start = 300
dem_vien_icon_start1 = 277
dem_vien_icon_start2 = 190

while run:  #vòng lặp chính của chương trình, chạy liên tục cho đến khi người dùng đóng cửa sổ

    for event in pygame.event.get():   #lấy tất cả các sự kiện từ hàng đợi sự kiện của Pygame
        if event.type == pygame.QUIT:  #nếu người dùng nhấn nút đóng cửa sổ
           run = False    #thiết lập run False để thoát khỏi vòng lặp chính khi người dùng đóng cửa sổ
    display.fill((28, 2, 61))   #màu nền cho giao diện khởi động

    # vẽ loading bar và hiệu ứng cho nó ,di chuyển icon boot
        #logic
    present_time = pygame.time.get_ticks()  #lấy thời gian hiện tại tính bằng mili giây kể từ khi Pygame được khởi tạo và lưu vào biến present_time
    if present_time - last_time >= 10:
        if dem_loading == 810:
            if hello_boot_alpha < 255:
                hello_boot_alpha += 5
                hello_boot.set_alpha(hello_boot_alpha)
            display.blit(hello_boot, (550, 150))
            if dem_icon_start > 200:
                dem_icon_start -= 1
            if dem_vien_icon_start1 > 180 :
                dem_vien_icon_start1 -= 1
            if dem_vien_icon_start2 > 190:
                dem_vien_icon_start2 -= 1
            if dem_icon_start == 200 and dem_vien_icon_start1 == 180 and dem_vien_icon_start2 == 190:
                pass
        if dem_loading < 810:
            dem_loading += 1
        last_time = present_time  #cập nhật giá trị của last_time bằng giá trị của present_time để theo dõi thời gian giữa các lần cập nhật
    pygame.draw.rect(display, (103, 28, 201), (539, dem_vien_icon_start1, 195,dem_vien_icon_start2))  #vẽ viền cho logo khởi động
    display.blit(logo_boot, (560, dem_icon_start))         #thêm logo khởi động vào

    pygame.draw.line(display, (173,110,255), (450, 530), (dem_loading, 530), 10)
    pygame.draw.circle(display, (173,110,255), (450, 531), ban_kinh)
    pygame.draw.circle(display, (173,110,255), (dem_loading,531), ban_kinh)
    pygame.display.update()
pygame.quit()