import pygame
pygame.init()   #khởi tạo Pygame để sử dụng các chức năng của nó
display = pygame.display.set_mode((1300, 800))  #tạo cửa sổ hiển thị với kích thước 1300x800 pixel
pygame.display.set_caption("booting...")  #đặt tiêu đề cho cửa sổ hiển thị là "booting..."

#bien 
dem_loading = 450
load_start = True
last_time = pygame.time.get_ticks()  #lấy thời gian hiện tại tính bằng mili giây kể từ khi Pygame được khởi tạo và lưu vào biến last_time
ban_kinh = 5
run = True #biến điều khiển vòng lặp chính của chương trình, ban đầu được đặt thành True để bắt đầu vòng lặp
x_icon_boot = 560
y_icon_boot = 300

x_vien_icon_boot = 539
y_vien_icon_boot = 277

dai_vien_icon_boot = 195
cao_vien_icon_boot = 190

dai_icon_boot = 154
cao_icon_boot = 145

x_hinh_tron_1 = 450
y_hinh_tron_1 = 531

y_hinh_tron_2 = 531


logo_boot_original = pygame.image.load(r"C:\Users\ble39\AppData\Roaming\leeiOS\system\lib\picture\logo_boot.png") #tải hình ảnh logo khởi động từ đường dẫn cụ thể và lưu vào biến logo_boot
logo_boot = pygame.transform.smoothscale(logo_boot_original, (dai_icon_boot, cao_icon_boot))  #tạo một bản sao của hình ảnh logo_boot và lưu vào biến logo_boot để có thể thay đổi kích thước mà không ảnh hưởng đến hình ảnh gốc
hello_boot_original = pygame.image.load(r"C:\Users\ble39\AppData\Roaming\leeiOS\system\lib\picture\hello_boot.png").convert_alpha() #tải hình ảnh hello boot từ đường dẫn cụ thể và lưu vào biến hello_boot
hello_boot = pygame.transform.smoothscale(hello_boot_original, (240, 100))  #tạo một bản sao của hình ảnh hello_boot và lưu vào biến hello_boot để có thể thay đổi độ trong suốt mà không ảnh hưởng đến hình ảnh gốc
hello_boot_alpha = 0
hello_boot.set_alpha(hello_boot_alpha)  #đặt độ trong suốt của hình ảnh hello_boot bằng giá trị của biến hello_boot_alpha (ban đầu là 0, tức là hoàn toàn trong suốt)

while run:  #vòng lặp chính của chương trình, chạy liên tục cho đến khi người dùng đóng cửa sổ

    for event in pygame.event.get():   #lấy tất cả các sự kiện từ hàng đợi sự kiện của Pygame
        if event.type == pygame.QUIT:  #nếu người dùng nhấn nút đóng cửa sổ
           run = False    #thiết lập run False để thoát khỏi vòng lặp chính khi người dùng đóng cửa sổ
    display.fill((28, 2, 61))   #màu nền cho giao diện khởi động

    # vẽ loading bar và hiệu ứng cho nó ,di chuyển icon boot
        #logic
    present_time = pygame.time.get_ticks()  #lấy thời gian hiện tại tính bằng mili giây kể từ khi Pygame được khởi tạo và lưu vào biến present_time
    if present_time - last_time >= 10:
        if dem_loading == 810:
            if y_icon_boot > 200:
                y_icon_boot -= 1
            if y_vien_icon_boot > 180 :
                y_vien_icon_boot -= 1
            if cao_vien_icon_boot > 190:
                cao_vien_icon_boot -= 1
            if y_icon_boot == 200 and y_vien_icon_boot == 180 and cao_vien_icon_boot == 190:
                if hello_boot_alpha < 255:
                    hello_boot_alpha += 5
                    hello_boot.set_alpha(hello_boot_alpha)
                    if hello_boot_alpha == 255:
                        pygame.time.delay(500)  #tạm dừng chương trình trong 500 mili giây (0.5 giây) sau khi hiệu ứng hoàn thành
                        #đi lên
                        if y_icon_boot > 20:
                            y_icon_boot -= 1
                        if y_vien_icon_boot > 0 :
                            y_vien_icon_boot -= 1
                        #chỉnh độ cao
                        if cao_vien_icon_boot > 65:
                            cao_vien_icon_boot -= 1
                        #chỉnh độ dài
                        if dai_vien_icon_boot > 60:
                            dai_vien_icon_boot -= 1
                        


        if dem_loading < 710:
            dem_loading += 1
        elif dem_loading >= 710 and dem_loading < 810:
            dem_loading += 2
        elif dem_loading == 810:
            pass
        last_time = present_time  #cập nhật giá trị của last_time bằng giá trị của present_time để theo dõi thời gian giữa các lần cập nhật            
    display.blit(hello_boot, (510, 410))
    pygame.draw.rect(display, (103, 28, 201), (x_vien_icon_boot, y_vien_icon_boot, dai_vien_icon_boot, cao_vien_icon_boot))  #vẽ viền cho logo khởi động
    display.blit(logo_boot, (x_icon_boot, y_icon_boot))         #thêm logo khởi động vào

    pygame.draw.line(display, (173,110,255), (x_hinh_tron_1, y_hinh_tron_1), (dem_loading, y_hinh_tron_2), 11)
    pygame.draw.circle(display, (173,110,255), (x_hinh_tron_1, y_hinh_tron_1), ban_kinh)
    pygame.draw.circle(display, (173,110,255), (dem_loading, y_hinh_tron_2), ban_kinh)
    pygame.display.update()
pygame.quit()